## ASC - Tema 2 - Operatii cu matrice

Mihai-Eugen Barbu, 335CA [2022]

----

### Surse

- **neopt**

    - am pornit de la implementarea clasica, realizand operatia
      data ca `C = ((B * A) * A**t) + (B**t * B)`

    - am tinut cont ca A este _superior triunghiulara_ folosind
      proprietatea ca `i <= j` pentru orice `A[i][j]` din partea superioara
        - astfel `j <= i` pentru `(A**t)[i][j]`

    - pentru fiecare inmultire pe matrice am folosit o variabila temporara,
      acumuland cei doi termeni ai adunarii la final

- **blas**

    - am tinut cont ca A este _superior triunghiulara_ folosind DTRMM [1]

    - pentru ca (B**t) * B este simetrica am folosit DSYRK [2]

- **opt**

    - pornind de la **neopt**, am optimizat progresiv pornind
      de la tehnicile prezentate in laborator [3], folosind:

        - reducerea matricilor auxiliare
            - sunt folosite doua matrice auxiliare
              (pentru `B * A`, respectiv pentru restul calculelor)

        - `register` - pentru constantele din buclele interioare

        - _pointeri_ - pentru accesul la vectori la incrementari

        - schimbarea _ordinii_ de executie a **buclelor**

            - am tinut cont in continuare ca A este _superior triunghiulara_
            - se tine cont de modul de acces facut de matricile transpuse

    - am obtinut constant un timp de **12.7-12.8** pe _nehalem_ pentru testul cu N = 1200

----

### Memory

Fisierele `*.memory` sunt de forma:

```c
$ command

<valgrind result>
```

### Cachegrind

Comenzile au fost rulate pe `nehalem-wn20`.

Tinand cont de notiunile din laborator [4], cat si de precizarile de la [5],
se pot analiza valorile obtinute astfel:

```
- **I** - _instructions_
    - I1 cache read misses
    - LLi cache instructions read misses

- **D** - _memory_
    - D1 cache read / write misses
    - LLd cache date read / write misses

- **Branches**
    - conditional
    - indirect
```

Pentru cele trei solutii se pot face urmatoarele observatii:

- **neopt**

    - rata de _miss_ in cazul instructiunilor este
      scazuta pentru ambele cache-uri

    - rata de _miss_ pentru D1 provine in principal de la **citiri**
        - cauza principala ar putea fi constituita de
          variabilele auxiliare folosite (*aux, *t1, *t2, *res),
          fiecare producand _miss_-uri atunci cand sunt utilizate

    - de remarcat ca LL _miss rate_ este calculat in
      raport cu numarul total de accesari de memorie

- **blas**

    - se remarca un numar semnificativ mai scazut de operatii (I, D)
      efectuate decat celelalte doua solutii
      (de aproximativ 10 ori fata de **opt**)

        - chiar daca procentele de _miss_ sunt mai mari
          (spre exemplu fata de **opt**),
          acest aspect este compensat de numarul scazut de accesari

    - de mentionat ca rezultatele functiilor _cblas_ sunt stocate
      in una din variabilele date ca parametru si nu sunt returnate

    - se observa un _miss rate_ mai ridicat
      in cazul **scrierilor** - ar putea fi un efect cauzat de punctul anterior

        - de exemplu, DTRMM(A, B) face o operatie de forma B = B * op(A)

    - in cazul _branch_-urilor, _miss_-urile ar putea fi cauzate
      de verificarile parametrilor din functii (`Cblas_<cond>`)
      pentru determinarea structurii matricelor si a operatiilor

- **opt**

    - procentul cel mai ridicat de _miss_ este
      cel de acces la memorie (D1) la **citire**

        - ar putea fi constituit de schimbarile de
          linii de cache necesare pentru _liniile_ matricelor

    - in cazul _branch_-urilor, se observa
      valori relativ _egale_ fata de varianta **neopt**

- **opt** vs **neopt**

    - _refs_ - este redus considerabil numarul de accesari
      pentru instructiuni / memorie

        - se poate datora reducerii variabilelor auxiliare
          (pentru matrice) folosite

    - LL _refs_ - se observa un numar de aproximativ
      10 ori mai mic pentru **opt**, care reduce semnificativ timpul
      (intrucat se fac mult mai putine accesari catre memoria principala)

        - se poate datora folosirii `register`
          pentru constantele din interiorul buclelor

        - folosirea de _pointeri_ pentru accesul
          incremental la matrice (_liniarizate_)

            - se tine cont de asezarea _row-major_

            - aici se evidentiaza si schimbarea **ordinii** buclelor
              pentru calculul inmultirilor astfel incat sa se produca
              un acces cat mai _secvential_ pentru cele doua matrice

----

### Grafice

Am rulat solutiile pentru valorile lui N din [400, 800, 1200, 1400, 1600].
Am atasat si timpii obtinuti (_graph\_times_) pe _nehalem_.

Se observa forme similare pentru cele trei grafice
in functie de _codomeniul_ fiecaruia (_Time[N]_).

- raportat la graficul cu toate solutiile,
**blas** are o forma aproape _liniara_

- **opt** vs **neopt**

    - am observat cum, optimizand progresiv prin metodele
      prezentate in laborator [3], timpul s-a redus - estimativ -
      sub forma (pentru N = 1200):

        - 34 -> 23 - reducerea matricelor auxiliare folosite 
                   + adaugarea `register`

        - 23 -> 19 - adaugarea de pointeri

        - 19 -> 14 - ordinea _buclelor_

        - 14 -> 12.7 - `register` + _pointer_ care este incrementat

    - am observat ca maximizarea folosirii de _pointeri_
      a redus timpul de cele mai multe ori

        - a contat aici _ordinea_ buclelor

            - de exemplu, pentru (B**t) * B, considerand i, j, k 
            -> ``(B**t)[i][k] * B[k][j] = B[k][i] * B[k][j]``, pe _nehalem_
               a parut ca ordinea `i-k-j` este mai eficienta decat `k-i-j`

        - pentru matricea auxiliara *t1, folosind pointeri (`*(ot1 + j)`)
          in loc de acces normal (`t1[i * N + j]`)

    -- am incercat sa optimizez si prin _BMM_ pe langa
       functionalitatile anterioare - in cadrul ultimei bucle
       (cu BLOCKSIZE = 40) - dar parea ca mareste timpul (cu 0.8-1 s)

----

### Resurse

[1] - http://www.netlib.org/lapack/explore-html/d1/d54/group__double__blas__level3_gaf07edfbb2d2077687522652c9e283e1e.html#gaf07edfbb2d2077687522652c9e283e1e

[2] - http://www.netlib.org/lapack/explore-html/d1/d54/group__double__blas__level3_gae0ba56279ae3fa27c75fefbc4cc73ddf.html#gae0ba56279ae3fa27c75fefbc4cc73ddf

[3] - https://ocw.cs.pub.ro/courses/asc/laboratoare/05

[4] - https://ocw.cs.pub.ro/courses/asc/laboratoare/06

[5] - https://valgrind.org/docs/manual/cg-manual.html
